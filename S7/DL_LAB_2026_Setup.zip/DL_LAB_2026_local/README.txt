DL LAB 2026 - local setup
1. Run install_dl_lab.bat from Anaconda Prompt (creates env DeepLearningLab).
2. Copy download_datasets.py and the datasets folder into your "DL LAB 2026" folder (next to EXP1..EXP10).
3. conda activate DeepLearningLab
   python download_datasets.py            (add --cifar for EXP3, --vgg for EXP6)
Notebooks are untouched. EXP2's !wget/!unzip and Colab drive-mount cells will still error - just skip them
(titanic.csv is already placed in EXP2).
