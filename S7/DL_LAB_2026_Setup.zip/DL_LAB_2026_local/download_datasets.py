"""
download_datasets.py  -  fetch the datasets referenced by the DL LAB 2026 notebooks.

Put this file (and the 'datasets' folder) in the lab root, next to EXP1 ... EXP10, then:

    conda activate DeepLearningLab
    python download_datasets.py            # everything small (default)
    python download_datasets.py --cifar    # also CIFAR-10   (~163 MB, needed by EXP3)
    python download_datasets.py --vgg      # also VGG19 weights (~80 MB, needed by EXP6)
    python download_datasets.py --force    # re-download even if files already exist

What it does (notebooks are NOT modified - files are placed where they already look):
  Titanic            -> datasets/titanic.csv                           + EXP2/titanic.csv
  NIFTY50 RELIANCE   -> datasets/NIFTY50_stock_data/RELIANCE.csv       + EXP9/NIFTY50_stock_data/RELIANCE.csv
  Hindi-English CSV  -> datasets/hindi_english_parallel.csv (first ~15 MB only) + EXP10/
  MNIST, IMDB        -> Keras cache (~/.keras/datasets) + copy in datasets/keras/
  CIFAR-10, VGG19    -> optional, same as above
"""
import argparse
import csv
import io
import re
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATASETS = ROOT / "datasets"

TITANIC_URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
HINDI_URL = "https://huggingface.co/datasets/Amitesh007/hin-eng-translatin-data/resolve/main/hindi_english_parallel.csv"
HINDI_MAX_BYTES = 15 * 1024 * 1024  # the notebook only samples 10,000 rows, so 15 MB is plenty


def log(msg):
    print(msg, flush=True)


def exp_dir(number):
    """Find the folder for an experiment (handles names like 'EXP5 ' with a trailing space)."""
    for p in ROOT.iterdir():
        if p.is_dir() and re.fullmatch(rf"EXP{number}\s*", p.name, re.I):
            return p
    return None


def copy_to_exp(src, number, relative_name):
    d = exp_dir(number)
    if d is None:
        log(f"   (EXP{number} folder not found next to this script - skipped copy)")
        return
    dest = d / relative_name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    log(f"   copied -> {dest.relative_to(ROOT)}")


def fetch(url, max_bytes=None, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    if max_bytes:
        req.add_header("Range", f"bytes=0-{max_bytes - 1}")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(max_bytes) if max_bytes else r.read()
    return data


# ---------------------------------------------------------------- Titanic (EXP2)
def get_titanic(force):
    target = DATASETS / "titanic.csv"
    if force or not target.exists():
        log("[Titanic] downloading...")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(fetch(TITANIC_URL))
    else:
        log("[Titanic] already in datasets/")
    copy_to_exp(target, 2, "titanic.csv")


# ---------------------------------------------------------------- NIFTY50 RELIANCE (EXP9)
def get_nifty(force):
    target = DATASETS / "NIFTY50_stock_data" / "RELIANCE.csv"
    if force or not target.exists():
        # The original data came as NIFTY50_stock_data.zip inside EXP9 - extract just RELIANCE.csv
        zips = list(ROOT.glob("EXP9*/NIFTY50_stock_data.zip")) + list(ROOT.glob("**/NIFTY50_stock_data.zip"))
        if not zips:
            log("[NIFTY50] RELIANCE.csv missing and NIFTY50_stock_data.zip not found - skipped")
            return
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zips[0]) as z:
            member = next(n for n in z.namelist() if n.endswith("RELIANCE.csv"))
            target.write_bytes(z.read(member))
        log(f"[NIFTY50] extracted RELIANCE.csv from {zips[0].name}")
    else:
        log("[NIFTY50] RELIANCE.csv already in datasets/")
    copy_to_exp(target, 9, "NIFTY50_stock_data/RELIANCE.csv")


# ---------------------------------------------------------------- Hindi-English (EXP10)
def trim_and_clean_csv(raw_bytes):
    """Drop the cut-off last row, keep only rows that parse, return CSV text with hindi/english columns."""
    text = raw_bytes.decode("utf-8", errors="ignore")
    text = text[: text.rfind("\n")]  # remove partial last line
    rows = list(csv.reader(io.StringIO(text)))
    header = [h.strip().lower() for h in rows[0]]
    if "hindi" not in header or "english" not in header:
        raise ValueError(f"Unexpected columns in file: {rows[0]}")
    n = len(header)
    good = [r for r in rows[1:] if len(r) == n]
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\n")
    w.writerow(rows[0])
    w.writerows(good[:-1] if good else good)  # last parsed row may still be cut mid-field
    return out.getvalue(), len(good) - 1


def get_hindi(force, url=HINDI_URL):
    target = DATASETS / "hindi_english_parallel.csv"
    if force or not target.exists():
        log("[Hindi-English] downloading first ~15 MB of the corpus (full file is 400 MB, not needed)...")
        try:
            raw = fetch(url, HINDI_MAX_BYTES, timeout=120)
            text, n = trim_and_clean_csv(raw)
        except Exception as e:
            log(f"   FAILED: {e}\n   Manual option: download hindi_english_parallel.csv from Kaggle "
                f"('Hindi English Truncated Corpus') into datasets/ and EXP10/.")
            return
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        log(f"   saved {n:,} sentence pairs")
    else:
        log("[Hindi-English] already in datasets/")
    copy_to_exp(target, 10, "hindi_english_parallel.csv")


# ---------------------------------------------------------------- Keras datasets / weights
def get_keras(cifar, vgg):
    try:
        from tensorflow.keras.datasets import mnist, imdb, cifar10
    except Exception:
        log("[Keras] TensorFlow not importable here - activate your DeepLearningLab env to fetch MNIST/IMDB.")
        return
    keras_cache = Path.home() / ".keras" / "datasets"
    out = DATASETS / "keras"
    out.mkdir(parents=True, exist_ok=True)

    log("[MNIST] (EXP1, EXP5, EXP6) ...")
    mnist.load_data()
    log("[IMDB]  (EXP7, EXP8) ...")
    imdb.load_data(num_words=10000)
    if cifar:
        log("[CIFAR-10] (EXP3) ~163 MB ...")
        cifar10.load_data()
    if vgg:
        log("[VGG19 weights] (EXP6) ~80 MB ...")
        from tensorflow.keras.applications import VGG19
        VGG19(weights="imagenet", include_top=False)

    # keep a portable copy of the small files in datasets/keras/
    for name in ("mnist.npz", "imdb.npz"):
        f = keras_cache / name
        if f.exists():
            shutil.copy2(f, out / name)
    log(f"   cached in {keras_cache} (Keras loads from there automatically)")


def main():
    ap = argparse.ArgumentParser(description="Download datasets for the DL lab notebooks.")
    ap.add_argument("--cifar", action="store_true", help="also fetch CIFAR-10 (~163 MB)")
    ap.add_argument("--vgg", action="store_true", help="also fetch VGG19 ImageNet weights (~80 MB)")
    ap.add_argument("--force", action="store_true", help="re-download even if files exist")
    ap.add_argument("--hindi-url", default=HINDI_URL, help=argparse.SUPPRESS)
    a = ap.parse_args()

    DATASETS.mkdir(exist_ok=True)
    for step in (lambda: get_titanic(a.force),
                 lambda: get_nifty(a.force),
                 lambda: get_hindi(a.force, a.hindi_url),
                 lambda: get_keras(a.cifar, a.vgg)):
        try:
            step()
        except Exception as e:  # never let one failure stop the rest
            log(f"   ERROR: {e}")
    log("\nDone. Datasets are in the 'datasets' folder and copied next to the notebooks that read them.")


if __name__ == "__main__":
    sys.exit(main())
