@echo off
setlocal EnableDelayedExpansion
title Deep Learning Lab - Full Toolkit Setup (CPU)

:: ============================================================
::  Deep Learning Lab - FULL TOOLKIT installer (Windows + Conda, CPU only)
::  Creates env "DeepLearningLab" (Python 3.10) with:
::   - TensorFlow 2.15 + Keras 2.15, PyTorch (CPU) + ecosystem
::   - OpenCV (full, with contrib), scikit-image, Pillow, imageio
::   - Data science, ML, NLP, time series, explainability, tuning
::   - JupyterLab + registered kernel
::  Run from "Anaconda Prompt" or "Miniconda Prompt".
:: ============================================================

set ENV_NAME=DeepLearningLab
set PY_VER=3.10
set FAILED=

where conda >nul 2>nul
if errorlevel 1 (
    echo [ERROR] conda not found. Open "Anaconda Prompt" or "Miniconda Prompt" and run this again.
    pause
    exit /b 1
)

:: Constraints keep TensorFlow 2.15 happy (it needs numpy 1 and protobuf 4)
set CONSTRAINTS=%TEMP%\dl_lab_constraints.txt
> "%CONSTRAINTS%" echo numpy==1.26.4
>> "%CONSTRAINTS%" echo protobuf^>=3.20.3,^<5
>> "%CONSTRAINTS%" echo opencv-python^<4.11
>> "%CONSTRAINTS%" echo opencv-contrib-python^<4.11
>> "%CONSTRAINTS%" echo opencv-python-headless^<4.11
set PIP_CONSTRAINT=%CONSTRAINTS%

echo.
echo [1/7] Creating conda environment "%ENV_NAME%" (Python %PY_VER%)...
call conda env remove -n %ENV_NAME% -y >nul 2>nul
call conda create -n %ENV_NAME% python=%PY_VER% pip -y
if errorlevel 1 goto :fail

set RUN=call conda run -n %ENV_NAME% --no-capture-output

echo.
echo [2/7] Upgrading pip...
%RUN% python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :fail

echo.
echo [3/7] Core scientific stack + OpenCV + image tools...
%RUN% python -m pip install numpy==1.26.4 pandas scipy scikit-learn matplotlib seaborn plotly statsmodels sympy networkx pillow imageio scikit-image "opencv-contrib-python<4.11" h5py tqdm openpyxl xlrd pydot graphviz joblib requests
if errorlevel 1 goto :fail

echo.
echo [4/7] TensorFlow 2.15 + Keras 2.15 (CPU)...
%RUN% python -m pip install tensorflow==2.15.1 keras==2.15.0 tensorflow-datasets tensorflow-hub keras-tuner
if errorlevel 1 goto :fail

echo.
echo [5/7] PyTorch (CPU build) + ecosystem...
%RUN% python -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto :fail
%RUN% python -m pip install pytorch-lightning torchmetrics torchinfo timm
if errorlevel 1 goto :fail

echo.
echo [6/7] Jupyter, NLP, ML, time-series and extras (installed one by one)...
for %%P in (
    jupyterlab notebook ipykernel ipywidgets
    nltk gensim spacy sentencepiece tokenizers transformers datasets evaluate
    xgboost lightgbm catboost imbalanced-learn mlxtend
    shap lime optuna tensorboard onnx onnxruntime
    pmdarima bokeh pytest black
) do (
    echo   - installing %%P
    %RUN% python -m pip install %%P
    if errorlevel 1 (
        echo   [WARN] %%P failed, continuing...
        set FAILED=!FAILED! %%P
    )
)

echo.
echo [7/7] Downloading NLP data and registering Jupyter kernel...
%RUN% python -m ipykernel install --user --name %ENV_NAME% --display-name "Deep Learning Lab"
%RUN% python -c "import nltk; [nltk.download(x) for x in ['punkt','punkt_tab','stopwords','wordnet','omw-1.4','vader_lexicon','averaged_perceptron_tagger']]"
%RUN% python -m spacy download en_core_web_sm

:: Safety net: make sure numpy stayed on 1.x for TensorFlow
%RUN% python -m pip install numpy==1.26.4

echo.
echo ================= Verifying installation =================
%RUN% python -c "import tensorflow as tf, keras, torch, torchvision, numpy, pandas, scipy, sklearn, cv2, skimage, seaborn, statsmodels, matplotlib; print('TensorFlow   :', tf.__version__); print('Keras        :', keras.__version__); print('PyTorch      :', torch.__version__, '| CUDA:', torch.cuda.is_available()); print('Torchvision  :', torchvision.__version__); print('NumPy        :', numpy.__version__); print('Pandas       :', pandas.__version__); print('SciPy        :', scipy.__version__); print('scikit-learn :', sklearn.__version__); print('OpenCV       :', cv2.__version__, '(contrib:', hasattr(cv2,'xfeatures2d'), ')'); print('scikit-image :', skimage.__version__); print('Matplotlib   :', matplotlib.__version__)"
if errorlevel 1 goto :fail

echo.
echo ===========================================================
echo  DONE!  To use the environment:
echo     conda activate %ENV_NAME%
echo     jupyter lab
echo  In Jupyter pick the kernel: "Deep Learning Lab"
if defined FAILED echo.
if defined FAILED echo  Optional packages that failed to install: %FAILED%
echo ===========================================================
pause
exit /b 0

:fail
echo.
echo [ERROR] Something failed. Scroll up to see which step, fix it, and re-run the script.
pause
exit /b 1
