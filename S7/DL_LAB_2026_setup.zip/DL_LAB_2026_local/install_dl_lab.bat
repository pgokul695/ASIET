@echo off
title Deep Learning Lab - Minimal Setup (CPU)
set ENV_NAME=DeepLearningLab

where conda >nul 2>nul
if errorlevel 1 (
    echo [ERROR] conda not found. Run this from Anaconda Prompt or Miniconda Prompt.
    pause
    exit /b 1
)

echo [1/5] Creating environment %ENV_NAME% (Python 3.10)...
call conda env remove -n %ENV_NAME% -y >nul 2>nul
call conda create -n %ENV_NAME% python=3.10 pip -y
if errorlevel 1 goto :fail

echo [2/5] Installing dependencies from requirements.txt...
call conda run -n %ENV_NAME% --no-capture-output python -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto :fail

echo [3/5] Registering Jupyter kernel and verifying...
call conda run -n %ENV_NAME% --no-capture-output python -m ipykernel install --user --name %ENV_NAME% --display-name "Deep Learning Lab"
call conda run -n %ENV_NAME% --no-capture-output python -c "import tensorflow as tf, keras, numpy, pandas, scipy, sklearn, matplotlib, seaborn, cv2; print('TensorFlow', tf.__version__, '| Keras', keras.__version__, '| NumPy', numpy.__version__, '| OpenCV', cv2.__version__)"
if errorlevel 1 goto :fail

echo [4/5] Downloading datasets to %USERPROFILE%\datasets ...
if exist "%~dp0download_datasets.py" (
    call conda run -n %ENV_NAME% --no-capture-output python "%~dp0download_datasets.py" --lab-dir "%~dp0"
) else (
    echo [WARN] download_datasets.py not found next to this script - skipping datasets.
)

echo [5/5] Verifying packages and datasets (offline readiness)...
if exist "%~dp0verify.py" (
    call conda run -n %ENV_NAME% --no-capture-output python "%~dp0verify.py"
) else (
    echo [WARN] verify.py not found next to this script - skipping.
)

echo.
echo DONE. Next:  conda activate %ENV_NAME%   then   jupyter notebook
echo Pick kernel "Deep Learning Lab".
echo Datasets: %USERPROFILE%\datasets
pause
exit /b 0

:fail
echo [ERROR] A step failed. Scroll up to see which one, then re-run.
pause
exit /b 1
