DL LAB 2026 - setup package (CPU, minimal dependencies)

Keep all files from this folder together:
  install_dl_lab.bat      Windows installer
  install_conda_linux.sh  Linux installer (does NOT touch your shell config)
  requirements.txt        minimal dependency list
  download_datasets.py    dataset downloader (called automatically by both installers)
  verify.py               checks packages, imports and datasets; prints top 10 rows of each
  datasets/               small bundled files (Titanic, RELIANCE) used to seed ~/datasets

WINDOWS  (Anaconda/Miniconda Prompt)
  install_dl_lab.bat
  conda activate DeepLearningLab
  jupyter notebook            -> datasets in %USERPROFILE%\datasets

LINUX
  bash install_conda_linux.sh
  Open "Conda Shell" from the app menu, then: jupyter notebook
  Datasets in /home/<you>/datasets

CHECK EVERYTHING (inside the activated env):
  python verify.py            (exit code 0 = all good)

Downloaded by default (everything the 10 experiments need, then works offline):
  MNIST, IMDB, CIFAR-10 (~163 MB), VGG19 ImageNet weights (~80 MB), Titanic, RELIANCE, Hindi-English.
To skip the big ones:  python download_datasets.py --no-cifar --no-vgg
Put this folder next to your EXP1..EXP10 folders (or pass --lab-dir) and the files are also
copied to where each notebook already reads them. Notebooks are never modified.
EXP2's !wget/!unzip and Colab drive-mount cells will still error - just skip them.
