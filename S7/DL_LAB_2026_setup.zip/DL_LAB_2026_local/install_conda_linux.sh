#!/usr/bin/env bash
# ==============================================================================
#  install_conda_linux.sh
#
#  - Installs Miniconda into ~/miniconda3 WITHOUT touching your shell:
#      no `conda init`, no PATH changes, no edits to .bashrc / .zshrc / .profile /
#      fish config. Your normal terminals behave exactly as before.
#  - Creates the env "DeepLearningLab" (Python 3.10) with the minimal lab deps.
#  - Downloads the lab datasets to ~/datasets (needs download_datasets.py next to this script).
#  - Adds a GNOME app-menu entry "Conda Shell" that opens a terminal with that
#    env activated. Conda only exists inside that terminal window.
#
#  Usage:   bash install_conda_linux.sh
#           bash install_conda_linux.sh --uninstall   (removes launcher only)
# ==============================================================================
set -euo pipefail

CONDA_DIR="${CONDA_DIR:-$HOME/miniconda3}"
ENV_NAME="DeepLearningLab"
PY_VER="3.10"
APP_DIR="$HOME/.local/share/conda-shell"
DESKTOP_FILE="$HOME/.local/share/applications/conda-shell.desktop"

# Minimal dependencies (same as requirements.txt / Windows setup)
REQUIREMENTS='tensorflow==2.15.1
keras==2.15.0
numpy==1.26.4
pandas
scipy
scikit-learn
matplotlib
seaborn
opencv-python<4.11
notebook
ipykernel'

log()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

# Shell startup files we promise never to change
PROTECTED_FILES=(
  "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.profile" "$HOME/.bash_login"
  "$HOME/.zshrc" "$HOME/.zprofile" "$HOME/.zshenv" "$HOME/.config/fish/config.fish"
)

snapshot_shell_files() {
  SNAP_DIR="$(mktemp -d)"
  for f in "${PROTECTED_FILES[@]}"; do
    if [ -e "$f" ]; then
      cp -p "$f" "$SNAP_DIR/$(echo "$f" | tr '/' '_')"
    else
      : > "$SNAP_DIR/$(echo "$f" | tr '/' '_').absent"
    fi
  done
}

verify_shell_files() {
  local changed=0
  for f in "${PROTECTED_FILES[@]}"; do
    local key; key="$SNAP_DIR/$(echo "$f" | tr '/' '_')"
    if [ -e "$key" ]; then
      if ! cmp -s "$f" "$key"; then
        warn "$f was modified during install - restoring original."
        cp -p "$key" "$f"; changed=1
      fi
    elif [ -e "$f" ]; then
      warn "$f was created during install - removing it."
      rm -f "$f"; changed=1
    fi
  done
  [ "$changed" -eq 0 ] && echo "Shell config files untouched. OK"
  rm -rf "$SNAP_DIR"
}

install_miniconda() {
  if [ -x "$CONDA_DIR/bin/conda" ]; then
    log "Miniconda already present at $CONDA_DIR - skipping download"
    return
  fi
  case "$(uname -m)" in
    x86_64)  ARCH="x86_64"  ;;
    aarch64) ARCH="aarch64" ;;
    *) die "Unsupported CPU architecture: $(uname -m)" ;;
  esac
  local url="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-${ARCH}.sh"
  local tmp; tmp="$(mktemp --suffix=.sh)"
  log "Downloading Miniconda ($ARCH)..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL --progress-bar -o "$tmp" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$tmp" "$url"
  else
    die "Need curl or wget installed."
  fi
  log "Installing Miniconda to $CONDA_DIR (batch mode, no shell init)..."
  # -b = batch (no prompts, no shell modification)  -p = target prefix
  bash "$tmp" -b -p "$CONDA_DIR"
  rm -f "$tmp"
}

create_env() {
  log "Creating env '$ENV_NAME' (Python $PY_VER) from conda-forge..."
  # --override-channels avoids the Anaconda 'defaults' channel and its ToS prompt
  "$CONDA_DIR/bin/conda" env remove -n "$ENV_NAME" -y >/dev/null 2>&1 || true
  "$CONDA_DIR/bin/conda" create -y -n "$ENV_NAME" --override-channels -c conda-forge \
      "python=$PY_VER" pip

  log "Installing dependencies with pip (this is the long step)..."
  local req; req="$(mktemp --suffix=.txt)"
  printf '%s\n' "$REQUIREMENTS" > "$req"
  "$CONDA_DIR/envs/$ENV_NAME/bin/python" -m pip install --upgrade pip
  "$CONDA_DIR/envs/$ENV_NAME/bin/python" -m pip install -r "$req"
  rm -f "$req"

  "$CONDA_DIR/envs/$ENV_NAME/bin/python" -m ipykernel install --user \
      --name "$ENV_NAME" --display-name "Deep Learning Lab" >/dev/null
}

download_datasets() {
  local runner; runner="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/download_datasets.py"
  log "Downloading datasets to $HOME/datasets ..."
  if [ -f "$runner" ]; then
    # Non-fatal: a failed download must not break the install
    "$CONDA_DIR/envs/$ENV_NAME/bin/python" "$runner" --lab-dir "$(dirname "$runner")" \
      || warn "Dataset download had problems - re-run: python download_datasets.py"
  else
    warn "download_datasets.py not found next to this script - skipping datasets."
  fi
}

write_launcher() {
  log "Creating 'Conda Shell' app-menu launcher..."
  mkdir -p "$APP_DIR" "$(dirname "$DESKTOP_FILE")"

  # Private rcfile: only used by the Conda Shell window, never by normal terminals
  cat > "$APP_DIR/conda-shell.bashrc" <<EOF
# Used only by the "Conda Shell" launcher (bash --rcfile).
# Set CONDA_SHELL_SOURCE_BASHRC=1 in the environment to also load your ~/.bashrc.
if [ "\${CONDA_SHELL_SOURCE_BASHRC:-0}" = "1" ] && [ -f "\$HOME/.bashrc" ]; then
  . "\$HOME/.bashrc"
fi
eval "\$('$CONDA_DIR/bin/conda' shell.bash hook)"
conda activate '$ENV_NAME'
cd "\$HOME"
echo "Conda shell ready  |  env: $ENV_NAME  |  type 'exit' to close"
EOF

  cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=Conda Shell
Comment=Terminal with the $ENV_NAME conda environment (isolated from your default shell)
Exec=bash --rcfile "$APP_DIR/conda-shell.bashrc" -i
Icon=utilities-terminal
Terminal=true
Categories=Development;Science;
StartupNotify=true
EOF
  chmod 644 "$DESKTOP_FILE"
  command -v update-desktop-database >/dev/null 2>&1 && \
    update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
}

verify_install() {
  log "Verifying..."
  "$CONDA_DIR/envs/$ENV_NAME/bin/python" - <<'PY'
import tensorflow as tf, keras, numpy, pandas, scipy, sklearn, matplotlib, seaborn, cv2
print("TensorFlow", tf.__version__, "| Keras", keras.__version__, "| NumPy", numpy.__version__,
      "| OpenCV", cv2.__version__)
PY
}

run_verify() {
  local v; v="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/verify.py"
  log "Verifying packages and datasets (offline readiness)..."
  if [ -f "$v" ]; then
    "$CONDA_DIR/envs/$ENV_NAME/bin/python" "$v" || warn "verify.py reported problems - see above."
  else
    warn "verify.py not found next to this script - skipping."
  fi
}

uninstall() {
  rm -f "$DESKTOP_FILE"
  rm -rf "$APP_DIR"
  echo "Removed the 'Conda Shell' launcher."
  echo "Miniconda itself is untouched. To remove it too:  rm -rf '$CONDA_DIR' ~/.conda ~/.condarc"
}

main() {
  [ "$(id -u)" -ne 0 ] || die "Run as a normal user, not root."
  if [ "${1:-}" = "--uninstall" ]; then uninstall; return; fi

  snapshot_shell_files
  install_miniconda
  create_env
  download_datasets
  write_launcher
  verify_install
  run_verify
  log "Checking your shell files were not modified..."
  verify_shell_files

  cat <<EOF

All done!
  * Open your app menu (Activities) and search for  "Conda Shell"
  * Your normal terminals are unchanged - 'conda' only exists in that window.
  * Inside it:  jupyter notebook   (kernel: "Deep Learning Lab")
  * Datasets are in:  $HOME/datasets
  * To remove the launcher later:  bash $(basename "$0") --uninstall
EOF
}

# Only run when executed, not when sourced (lets the functions be tested)
if [ "${BASH_SOURCE[0]}" = "$0" ]; then main "$@"; fi
