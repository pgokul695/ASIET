"""
verify.py - checks that the DL LAB 2026 environment is ready.

    conda activate DeepLearningLab
    python verify.py                 # uses ~/datasets
    python verify.py --dest D:\\data # custom dataset folder

1. Every required package imports (with versions), plus the exact submodules the notebooks use
2. A tiny TensorFlow computation actually runs
3. Every dataset exists, and its top 10 rows are printed
Exit code is 0 if everything required passes, 1 otherwise.
"""
import argparse
import importlib
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):  # Hindi text must not crash a Windows console
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

OK, FAIL, OPT = "[ OK ]", "[FAIL]", "[ -- ]"
failures = []


def header(title):
    print("\n" + "=" * 70 + f"\n{title}\n" + "=" * 70)


def record(ok, label, detail="", required=True):
    mark = OK if ok else (FAIL if required else OPT)
    print(f"{mark} {label}" + (f"  -  {detail}" if detail else ""))
    if not ok and required:
        failures.append(label)


# ------------------------------------------------------------------ 1. packages
PACKAGES = [  # (import name, pip name)
    ("tensorflow", "tensorflow"), ("keras", "keras"), ("numpy", "numpy"),
    ("pandas", "pandas"), ("scipy", "scipy"), ("sklearn", "scikit-learn"),
    ("matplotlib", "matplotlib"), ("seaborn", "seaborn"), ("cv2", "opencv-python"),
    ("notebook", "notebook"), ("ipykernel", "ipykernel"),
]

# Exactly what the notebooks import
NOTEBOOK_IMPORTS = [
    "tensorflow.keras.models", "tensorflow.keras.layers", "tensorflow.keras.optimizers",
    "tensorflow.keras.callbacks", "tensorflow.keras.initializers",
    "tensorflow.keras.datasets", "tensorflow.keras.applications",
    "tensorflow.keras.preprocessing.text", "tensorflow.keras.preprocessing.sequence",
    "keras.models", "keras.layers", "keras.datasets",
    "sklearn.cluster", "sklearn.ensemble", "sklearn.model_selection",
    "sklearn.preprocessing", "sklearn.metrics", "scipy.stats",
]


def check_packages():
    header("1. PACKAGES")
    print(f"Python {sys.version.split()[0]}  |  {sys.executable}")
    for mod, pip_name in PACKAGES:
        try:
            m = importlib.import_module(mod)
            version = getattr(m, "__version__", "?")
            detail = f"{pip_name} {version}"
            if mod == "numpy" and version.startswith("2"):
                record(False, mod, detail + "  (TensorFlow 2.15 needs numpy 1.x: pip install numpy==1.26.4)")
            else:
                record(True, mod, detail)
        except Exception as e:
            record(False, mod, f"{type(e).__name__}: {e}  ->  pip install {pip_name}")

    print("\nNotebook imports:")
    bad = []
    for name in NOTEBOOK_IMPORTS:
        try:
            importlib.import_module(name)
        except Exception as e:
            bad.append(f"{name} ({type(e).__name__})")
    record(not bad, f"{len(NOTEBOOK_IMPORTS) - len(bad)}/{len(NOTEBOOK_IMPORTS)} notebook modules import",
           "; ".join(bad))

    try:
        import tensorflow as tf
        out = tf.reduce_sum(tf.constant([[1.0, 2.0], [3.0, 4.0]])).numpy()
        model = tf.keras.Sequential([tf.keras.layers.Dense(2, input_shape=(3,))])
        model.predict(tf.zeros((1, 3)), verbose=0)
        gpus = tf.config.list_physical_devices("GPU")
        record(out == 10.0, "TensorFlow runs a computation + builds a Keras model",
               "CPU only" if not gpus else f"{len(gpus)} GPU(s)")
    except Exception as e:
        record(False, "TensorFlow runtime test", f"{type(e).__name__}: {e}")


# ------------------------------------------------------------------ 2. datasets
def show_csv(path, label, required=True):
    if not path.exists():
        record(False, label, f"missing: {path}  ->  python download_datasets.py", required)
        return
    try:
        import pandas as pd
        pd.set_option("display.width", 200)
        pd.set_option("display.max_columns", 20)
        pd.set_option("display.max_colwidth", 40)
        df = pd.read_csv(path)
        record(True, label, f"{df.shape[0]:,} rows x {df.shape[1]} cols  ({path.stat().st_size / 1024:,.0f} KB)")
        print(f"       columns: {list(df.columns)}")
        print(df.head(10).to_string().replace("\n", "\n       "))
        print()
    except Exception as e:
        record(False, label, f"{type(e).__name__}: {e}", required)


def find(*candidates):
    return next((p for p in candidates if p.exists()), None)


def check_datasets(dest):
    header(f"2. DATASETS  ({dest})")
    keras_cache = Path.home() / ".keras" / "datasets"

    show_csv(dest / "titanic.csv", "Titanic (EXP2)")
    show_csv(dest / "NIFTY50_stock_data" / "RELIANCE.csv", "NIFTY50 RELIANCE (EXP9)")
    show_csv(dest / "hindi_english_parallel.csv", "Hindi-English pairs (EXP10)")

    try:
        import numpy as np
    except Exception:
        record(False, "numpy needed to read MNIST/IMDB")
        return

    p = find(keras_cache / "mnist.npz", dest / "keras" / "mnist.npz")
    if p:
        with np.load(p) as d:
            x, y = d["x_train"], d["y_train"]
            record(True, "MNIST (EXP1, 5, 6)", f"train {x.shape}, test {d['x_test'].shape}")
            print(f"       first 10 train labels: {y[:10].tolist()}")
            print(f"       first image, 10 pixels from the middle row: {x[0][14][9:19].tolist()}\n")
    else:
        record(False, "MNIST (EXP1, 5, 6)", "not found  ->  python download_datasets.py")

    p = find(keras_cache / "imdb.npz", dest / "keras" / "imdb.npz")
    if p:
        with np.load(p, allow_pickle=True) as d:
            x, y = d["x_train"], d["y_train"]
            record(True, "IMDB reviews (EXP7, 8)", f"{len(x):,} train reviews, {len(d['x_test']):,} test reviews")
            print(f"       first 10 train labels: {y[:10].tolist()}")
            print(f"       first review, first 10 token ids: {list(x[0][:10])}\n")
    else:
        record(False, "IMDB reviews (EXP7, 8)", "not found  ->  python download_datasets.py")

        cifar = keras_cache / "cifar-10-batches-py"
    if cifar.exists():
        try:
            from tensorflow.keras.datasets import cifar10  # loads from the local cache, no download
            (xtr, ytr), (xte, _) = cifar10.load_data()
            record(True, "CIFAR-10 (EXP3, EXP4)", f"train {xtr.shape}, test {xte.shape}")
            print(f"       first 10 train labels: {ytr[:10].ravel().tolist()}")
            print(f"       first image, first 10 pixel values (R,G,B): {xtr[0][0][:10].tolist()}\n")
        except Exception as e:
            record(False, "CIFAR-10 (EXP3, EXP4)", f"{type(e).__name__}: {e}")
    else:
        record(False, "CIFAR-10 (EXP3, EXP4)", "not found  ->  python download_datasets.py")
    vgg = Path.home() / ".keras" / "models" / "vgg19_weights_tf_dim_ordering_tf_kernels_notop.h5"
    if vgg.exists():
        try:
            from tensorflow.keras.applications import VGG19
            m = VGG19(weights="imagenet", include_top=False, input_shape=(48, 48, 3))
            record(True, "VGG19 + ImageNet weights (EXP6)",
                   f"{len(m.layers)} layers, {m.count_params():,} params, weights load offline ({vgg.stat().st_size / 1e6:.0f} MB)")
        except Exception as e:
            record(False, "VGG19 + ImageNet weights (EXP6)", f"{type(e).__name__}: {e}")
    else:
        record(False, "VGG19 weights (EXP6)", "not found  ->  python download_datasets.py")


def main():
    ap = argparse.ArgumentParser(description="Verify the DL lab environment and datasets.")
    ap.add_argument("--dest", help="dataset folder (default: ~/datasets)")
    a = ap.parse_args()
    dest = Path(a.dest).expanduser().resolve() if a.dest else Path.home() / "datasets"

    check_packages()
    check_datasets(dest)

    header("SUMMARY")
    if failures:
        print(f"{FAIL} {len(failures)} problem(s):")
        for f in failures:
            print(f"   - {f}")
        return 1
    print(f"{OK} Everything required is installed, importable and the datasets are available.")
    print("     All 10 experiments can now run OFFLINE (data is on disk, Keras reads its local cache).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
